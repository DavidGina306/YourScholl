@include('layouts.includes.header')

@include('layouts.includes.page')

@yield('conteudo')



@include('layouts.includes.footer')
@yield('scripts')